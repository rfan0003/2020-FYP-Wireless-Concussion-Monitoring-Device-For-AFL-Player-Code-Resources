package com.example.android.bluetoothlegatt;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SaveDataPage extends Activity implements OnClickListener{

    public static EditText mPathName;
    private EditText mFileName;
    private EditText mContent;
    private Button mTest;
    private Button mBtnRead;
    private TextView mShowTet;
    public static String filePath;
    public static String fileName1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.save_data_page);
        findid();

    }

    private void findid() {
        mPathName = (EditText) findViewById(R.id.et_pathName);
        mFileName = (EditText) findViewById(R.id.et_fileName);
        mTest = (Button) findViewById(R.id.btn_test);
        mTest.setOnClickListener(this);
    }

    private void getcontent() {
        //Create File Dynamically
        String pathName = mPathName.getText().toString();
        String fileName = mFileName.getText().toString();
        //String content = mContent.getText().toString();
        String content = null;
        if (TextUtils.isEmpty(pathName)) {
            Toast.makeText(this, "Name of Foler cannot be empty", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(fileName)) {
            Toast.makeText(this, "Name of File cannot be empty", Toast.LENGTH_SHORT).show();
        } else {
            Tool tool = new Tool();
            filePath = Environment.getExternalStorageDirectory()
                    .getPath() + "/" + pathName + "/";
            fileName1 = fileName + ".txt";

            tool.writeTxtToFile(content, filePath, fileName1);// 将字符串写入到文本文件中
            Toast.makeText(this, "Creation Success", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_test:
                getcontent();
                break;
        }
    }

    public void ScanBlePage(View view){
        Intent intent = new Intent(this, DeviceScanActivity.class);
        startActivity(intent);
    }
}
