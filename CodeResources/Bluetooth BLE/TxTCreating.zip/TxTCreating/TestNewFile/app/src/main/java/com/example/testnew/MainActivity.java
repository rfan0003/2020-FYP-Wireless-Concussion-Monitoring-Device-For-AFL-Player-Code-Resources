package com.example.testnew;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * By abc
 */

public class MainActivity extends Activity implements OnClickListener {

    private EditText mPathName;
    private EditText mFileName;
    private EditText mContent;
    private Button mTest;
    private Button mBtnRead;
    private TextView mShowTet;
    String filePath;
    String fileName1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findid();

    }

    private void findid() {
        mPathName = (EditText) findViewById(R.id.et_pathName);
        mFileName = (EditText) findViewById(R.id.et_fileName);
        mContent = (EditText) findViewById(R.id.et_content);
        mTest = (Button) findViewById(R.id.btn_test);


        mShowTet = (TextView) findViewById(R.id.Show_tet);
        mTest.setOnClickListener(this);

    }

    private void getcontent() {
        //Create Data file name and location name
        String pathName = mPathName.getText().toString();
        String fileName = mFileName.getText().toString();
        String content = mContent.getText().toString();
        if (TextUtils.isEmpty(pathName)) {
            Toast.makeText(this, "The Folder Name cannot be Empty", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(fileName)) {
            Toast.makeText(this, "The File Name cannot be Empty", Toast.LENGTH_SHORT).show();
        } else {
            Tool tool = new Tool();
            filePath = Environment.getExternalStorageDirectory()
                    .getPath() + "/" + pathName + "/";
            fileName1 = fileName + ".txt";

            tool.writeTxtToFile(content, filePath, fileName1);// Write the string into txt file
            Toast.makeText(this, "Creating Successful", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_test:
                getcontent();
                break;
        }
    }
}
